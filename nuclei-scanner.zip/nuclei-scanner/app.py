from flask import Flask, render_template, request
import os
import subprocess
from datetime import datetime
from urllib.parse import urlparse

app = Flask(__name__)
RESULTS_DIR = "results"
os.makedirs(RESULTS_DIR, exist_ok=True)


def is_valid_url(target: str) -> bool:
    parsed = urlparse(target)
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    error = None

    if request.method == "POST":
        target = request.form.get("target", "").strip()

        if not is_valid_url(target):
            error = "Please enter a valid URL starting with http:// or https://"
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(RESULTS_DIR, f"scan_{timestamp}.txt")

            try:
                command = ["nuclei", "-u", target, "-o", output_file]
                subprocess.run(command, check=True, capture_output=True, text=True)

                with open(output_file, "r", encoding="utf-8", errors="ignore") as file:
                    result = file.read() or "Scan finished. No findings found."

            except FileNotFoundError:
                error = "Nuclei is not installed or not available in PATH."
            except subprocess.CalledProcessError as e:
                error = e.stderr or "Nuclei scan failed."

    return render_template("index.html", result=result, error=error)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
